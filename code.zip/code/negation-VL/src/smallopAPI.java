import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Queue;

import org.apache.commons.io.FileUtils;
import org.apache.maven.shared.invoker.MavenInvocationException;
import org.omg.PortableServer.ServantActivator;

import com.sun.swing.internal.plaf.metal.resources.metal_zh_TW;

import soot.dava.toolkits.base.renamer.infoGatheringAnalysis;
import sun.misc.Cleaner;

public class smallopAPI {

	
	public static void setup() throws IOException, MavenInvocationException{// setup work for the experiment
		clean_exclude();
		clean_negate();
		clean_skip();
		set_testtimeout();
		set_exclude_class();
		mvnop.mvn_command("clean", wholeprocess.pomxmlfile1);
		mvnop.mvn_command("test", wholeprocess.pomxmlfile1);
		mvnop.mvn_command("clean", wholeprocess.pomxmlfileo2);
		mvnop.mvn_command("test", wholeprocess.pomxmlfileo2);
		
	}
	
	public static void mutantloop(int mutantid) throws IOException, MavenInvocationException{ //1-original kill 2-we kill 0-neither kill
		copy_originalv2_to_mutant_dir();
		seed_mutant(mutantid);
		set_and_create_all_logpath(mutantid);
		clean_negate();
		clean_skip();
		
		


		wholeprocess.mutant_kill = 0;
		wholeprocess.count_negate = 0;
		mvnop.mvn_command("clean", wholeprocess.pomxmlfile2);
		mvnop.mvn_command("test", wholeprocess.pomxmlfile2);
		assertionAPI.get_assertion(wholeprocess.assertoutput2, wholeprocess.asserty1path, wholeprocess.buildxmlfile2, false, wholeprocess.faltfilesdir2);
		if(assertionAPI.compare_diff_assertion_inalltest(wholeprocess.asserty1path, wholeprocess.asserto1path)){
			wholeprocess.mutant_kill = 1;
			return;
		}
		
//		if(assertionAPI.compare_diff_assertion_inalltest(wholeprocess.assertx1path, wholeprocess.asserty1path)){
//			wholeprocess.mutant_kill = 2;
//			return;
//		}
		
		
		
		wholeprocess.branch_cover_beforeNG_total.clear();
		wholeprocess.branch_cover_AftereNG_total.clear();
		MAPtotal.methodMap(false);
		approach.opti_get_originalcove();
		HashSet<String> cove_once = approach.analysis_coverage(false, false);
		Queue<List<String>> negate_queue = approach.initial_queue(cove_once);
		approach.negate(wholeprocess.strategy, negate_queue, false, true);

		
	}
	
	public static void write_kill_result() throws IOException{
		File kill = new File(wholeprocess.killpath);
		FileWriter fwkill = new FileWriter(kill);
		BufferedWriter bwkill = new BufferedWriter(fwkill);
		bwkill.write(String.valueOf(wholeprocess.mutant_kill));
		bwkill.newLine();
		bwkill.close();
		fwkill.close();
	}
	
	public static void step1() throws IOException, MavenInvocationException{ // collect x1, o1, get the increase branch coverage
		copy_originalv2_to_mutant_dir();
		set_and_create_all_logpath(0);
		mvnop.mvn_command("clean", wholeprocess.pomxmlfile1);
		mvnop.mvn_command("test", wholeprocess.pomxmlfile1);
		mvnop.mvn_command("clean", wholeprocess.pomxmlfile2);
		mvnop.mvn_command("test", wholeprocess.pomxmlfile2);
		assertionAPI.get_assertion(wholeprocess.assertoutput1, wholeprocess.assertx1path, wholeprocess.buildxmlfile1, false, wholeprocess.faltfilesdir1);
		assertionAPI.get_assertion(wholeprocess.assertoutput2, wholeprocess.asserto1path, wholeprocess.buildxmlfile2, false,wholeprocess.faltfilesdiro2);
		approach.get_increase_branch();
	}

	
	public static void set_exclude_class() throws IOException, MavenInvocationException{ // get exclude class in target in o2, and write to v1 and o2

		//1.get target directory
		mvnop.mvn_command("clean", wholeprocess.pomxmlfileo2);
		mvnop.mvn_command("test", wholeprocess.pomxmlfileo2);
		
		//2. get the exclude class in o2
		String testclasspath = wholeprocess.original_project2_home + wholeprocess.testbinary_dir_prefix;
		getallfile.cFile.clear();
		getallfile.readAllFile(testclasspath);
		
	
		//3. write the exclude class in v1 and o2
		FileWriter excludewrite1 = new FileWriter(new File(wholeprocess.exclude_data1));
		BufferedWriter excludebuff1 = new BufferedWriter(excludewrite1);
		FileWriter excludewrite2 = new FileWriter(new File(wholeprocess.exclude_datao2));
		BufferedWriter excludebuff2 = new BufferedWriter(excludewrite2); 
		
		for(File files: getallfile.cFile){
			
			String path_s = files.getAbsolutePath();
	
			if (path_s.endsWith(".class") ) {
				String pathToWrite = null;
				if(path_s.toString().contains("test-classes")){
					pathToWrite = path_s.substring(path_s.indexOf("test-classes") + 13, path_s.indexOf(".class"));
				}
				String className = pathToWrite.replaceAll("\\\\", ".");
				excludebuff1.write(className);
				excludebuff1.newLine();
				excludebuff2.write(className);
				excludebuff2.newLine();
			}
		}
		excludebuff1.close();
		excludewrite1.close();
		excludebuff2.close();
		excludewrite2.close();
	}
	
	public static void set_testtimeout() throws IOException{ // set the test time out in v1 and o2
		String testpath = wholeprocess.project1_home + wholeprocess.testsrc_dir_prefix;
		List<String> read_test = new ArrayList<String>();
		getallfile.cFile.clear();
		getallfile.readAllFile(testpath);
		for(File files: getallfile.cFile){
			read_test.clear();
			FileReader fr = new FileReader(files);
			BufferedReader br= new BufferedReader(fr);
			String tmp;
			while((tmp = br.readLine()) != null){
				if(tmp.trim().contains("@Test") && tmp.trim().indexOf("@Test") == 0 && !tmp.trim().contains("timeout =")){
					String t_a;
					tmp = tmp.trim();
					if(!tmp.equals("@Test")){
						t_a= tmp;
						t_a = t_a.substring(0, t_a.length() - 1);
						t_a = t_a + ",timeout = 300)";
					}
					else
						t_a = "@Test(timeout = 300)";
					read_test.add(t_a);
				}
				else
					read_test.add(tmp);
			}
			br.close();
			fr.close();
			FileWriter fw = new FileWriter(files);
			BufferedWriter bw= new BufferedWriter(fw);
			for(String item: read_test){
				bw.write(item);
				bw.newLine();
			}
			bw.close();
			fw.close();
		} 

		
		
		testpath = wholeprocess.original_project2_home + wholeprocess.testsrc_dir_prefix;
		getallfile.cFile.clear();
		getallfile.readAllFile(testpath);
		for(File files: getallfile.cFile){
			read_test.clear();
			FileReader fr = new FileReader(files);
			BufferedReader br= new BufferedReader(fr);
			String tmp;
			while((tmp = br.readLine()) != null){
				if(tmp.trim().contains("@Test") && tmp.trim().indexOf("@Test") == 0 && !tmp.trim().contains("timeout =")){
					String t_a;
					tmp = tmp.trim();
					if(!tmp.equals("@Test")){
						t_a= tmp;
						t_a = t_a.substring(0, t_a.length() - 1);
						t_a = t_a + ",timeout = 300)";
					}
					else
						t_a = "@Test(timeout = 300)";
					read_test.add(t_a);
				}
				else
					read_test.add(tmp);
			}
			br.close();
			fr.close();
			FileWriter fw = new FileWriter(files);
			BufferedWriter bw= new BufferedWriter(fw);
			for(String item: read_test){
				bw.write(item);
				bw.newLine();
			}
			bw.close();
			fw.close();
		} 	
	}

	public static void copy_originalv2_to_mutant_dir() throws IOException{ // copy the dir from o2 to v2
		File from_dir = new File(wholeprocess.original_project2_home);
		File to_dir = new File(wholeprocess.v2_home);
		if(to_dir.exists())
			FileUtils.cleanDirectory(to_dir);
		FileUtils.copyDirectoryToDirectory(from_dir, to_dir);
	}

	public static void seed_mutant(int mutantid) throws IOException{
		File mutant_file = new File(wholeprocess.mutants_dir_path + "\\" + String.valueOf(mutantid) + "\\" + wholeprocess.src_prefic);
		File src_dir = new File(wholeprocess.src_dir_path);
		FileUtils.copyDirectoryToDirectory(mutant_file, src_dir);
	}
	
	static void set_xml_to_true_false(boolean flag, String buildxml) throws IOException { // negate option in the build.xml to true or false 
		
		List<String> xml_rewrite = new ArrayList<String>();
		xml_rewrite.clear();
		
		File rewrite_file = new File(buildxml);
		FileReader rewrite_fr = new FileReader(rewrite_file);
		BufferedReader rewrite_br = new BufferedReader(rewrite_fr);
		
		String tmps1;
		String tmps3;
		int tmp_count = 0;
		while ((tmps1 = rewrite_br.readLine()) != null) {
			tmp_count++;
			if (tmp_count == 5) {
				String tmps2[] = tmps1.split("value=");
				tmps3 = tmps2[0] + "value= \"true\" />";
				xml_rewrite.add(tmps3);
			} 
			else if (tmp_count == 6) {
				if (flag == true) {
					String tmps2[] = tmps1.split("value=");
					tmps3 = tmps2[0] + "value= \"true\" />";
					xml_rewrite.add(tmps3);
				} else {
					String tmps2[] = tmps1.split("value=");
					tmps3 = tmps2[0] + "value= \"false\" />";
					xml_rewrite.add(tmps3);
				}
			} 
			else {
				xml_rewrite.add(tmps1);
			}

		}

		rewrite_br.close();
		rewrite_fr.close();

		FileWriter rewrite_fw = new FileWriter(rewrite_file);
		BufferedWriter rewrite_bw = new BufferedWriter(rewrite_fw);
		for (String item : xml_rewrite) {
			rewrite_bw.write(item);
			rewrite_bw.newLine();
		}
		rewrite_bw.close();
		rewrite_fw.close();
	}
	
	static void set_and_create_all_logpath(int mutantid){// set value of x1x2y1y2o1o2logpath
		wholeprocess.logpath = wholeprocess.result_path + "\\" + String.valueOf(mutantid);
		File f = new File(wholeprocess.logpath);
		if(!f.exists())
			f.mkdir();
		
		wholeprocess.assertx1path = wholeprocess.result_path + "\\0\\assertx1.txt";
		wholeprocess.asserto1path = wholeprocess.result_path + "\\0\\asserto1.txt";
		
		wholeprocess.assertx2path = wholeprocess.logpath + "\\assertx2.txt";
		wholeprocess.asserto2path = wholeprocess.logpath + "\\asserto2.txt";
		wholeprocess.asserty1path = wholeprocess.logpath + "\\asserty1.txt";
		wholeprocess.asserty2path = wholeprocess.logpath + "\\asserty2.txt";
		wholeprocess.killpath = wholeprocess.logpath + "\\kill.txt";

	}

	public static void clean_skip(){
		File file_to_delete = new File(wholeprocess.skip1);
		if(file_to_delete.exists())
			file_to_delete.delete();
		file_to_delete = new File(wholeprocess.skip2);
		if(file_to_delete.exists())
			file_to_delete.delete();
		file_to_delete = new File(wholeprocess.skipo2);
		if(file_to_delete.exists())
			file_to_delete.delete();
	}
	
	public static void clean_exclude(){
		File file_to_delete = new File(wholeprocess.exclude_data1);
		if(file_to_delete.exists())
			file_to_delete.delete();
		file_to_delete = new File(wholeprocess.exclude_data2);
		if(file_to_delete.exists())
			file_to_delete.delete();
		file_to_delete = new File(wholeprocess.exclude_datao2);
		if(file_to_delete.exists())
			file_to_delete.delete();
	}
	
	public static void clean_negate(){
		File file_to_delete = new File(wholeprocess.negate_list1);
		if(file_to_delete.exists())
			file_to_delete.delete();
		file_to_delete = new File(wholeprocess.negate_list2);
		if(file_to_delete.exists())
			file_to_delete.delete();
		file_to_delete = new File(wholeprocess.negate_listo2);
		if(file_to_delete.exists())
			file_to_delete.delete();
	}
	
}
