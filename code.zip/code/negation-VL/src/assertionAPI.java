import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.Buffer;
import java.util.HashMap;
import java.util.Iterator;

public class assertionAPI {

		

	
	public static void move_assertion(String fromfile, String tofile) throws IOException { // copy assertion output from fromdir to todir, if from is not exit, to is empty; and the from will be delete
		File f1 = new File(fromfile);
		File f2 = new File(tofile);

		if(f2.exists())
			f2.delete();
		
		if (!f1.exists()) {
			f2.createNewFile();
		} 
		else {
			FileReader fr = new FileReader(f1);
			BufferedReader br = new BufferedReader(fr);
			FileWriter fw = new FileWriter(f2);
			BufferedWriter bw = new BufferedWriter(fw);
			String tmp;
			while ((tmp = br.readLine()) != null) {
				bw.write(tmp);
				bw.newLine();
			}
			bw.close();
			fw.close();
			br.close();
			fr.close();
			f1.delete();
		}
	}
	
	public static void get_assertion(String fromfile, String tofile, String buildxml, boolean negate_flag, String faultfilepath) throws IOException{// collect the assert and copy to the dst
		File f = new File(fromfile);
		if(f.exists())
			f.delete();
		antop.load_branch_assertoutput(negate_flag, buildxml,faultfilepath);
		move_assertion(fromfile, tofile);
	}
		
	public static void clear_all_assertoutput(){ // xlear the assertoutput in v1 v2 o2
		File f = new File(wholeprocess.assertoutput1);
		if(f.exists())
			f.delete();
		f = new File(wholeprocess.assertoutput2);
		if(f.exists())
			f.delete();
		f = new File(wholeprocess.assertoutputo2);
		if(f.exists())
			f.delete();
		
	}
	
	public static HashMap<String, String> get_assert_apart_intestmethod(String assertionfile) throws IOException{// depart assertoutput in method granularity
		HashMap<String, String> cmp = new HashMap<String, String>();
		File f = new File(assertionfile);
		FileReader fr = new FileReader(f);
		BufferedReader br = new BufferedReader(fr);
		
		String tmp1, tmpname;
		String tmparray[];
		tmpname = "";
		
		while((tmp1 = br.readLine()) != null){
			String real_tmp;
			if(!tmp1.trim().split(" ")[0].contains(":") || !tmp1.trim().split(" ")[0].contains(wholeprocess.project_prefix) ){
				if(cmp.containsKey(tmpname)){
					real_tmp = cmp.get(tmpname);
					if(!real_tmp.equals(""))
						real_tmp += "\n";
					real_tmp += tmp1;
					cmp.put(tmpname, real_tmp);
				}
				continue;
			}
				
			tmparray = tmp1.trim().split(" ")[0].split(":");
			tmpname = tmparray[0] + "." + tmparray[1];
			if(!cmp.containsKey(tmpname))
				cmp.put(tmpname,"");
			real_tmp = cmp.get(tmpname);
			if(!real_tmp.equals(""))
				real_tmp += "\n";
			real_tmp += tmp1;
			cmp.put(tmpname, real_tmp);	
		}
		
		br.close();
		fr.close();
		
		return cmp;
		
	}
	
	public static boolean compare_diff_assertion_inalltest(String assertion1, String assertion2) throws IOException{ // compare the assertion1 and assrtion2 in all tests
		
		HashMap<String, String> cmp1 = get_assert_apart_intestmethod(assertion1);
		HashMap<String, String> cmp2 = get_assert_apart_intestmethod(assertion2);
		

		
		
		boolean diff_flag = false;
		
		Iterator iter = cmp1.entrySet().iterator();
		while (iter.hasNext()) {
			HashMap.Entry entry = (HashMap.Entry) iter.next();
			String tmp_method = (String) entry.getKey();
			if(compare_unit(cmp1, cmp2, tmp_method)){
				diff_flag = true;
				break;
			}

		}
		
		iter = cmp2.entrySet().iterator();
		while (iter.hasNext()) {
			HashMap.Entry entry = (HashMap.Entry) iter.next();
			String tmp_method = (String) entry.getKey();
			if(compare_unit(cmp1, cmp2, tmp_method)){
				diff_flag = true;
				break;
			}
		}
		
		return diff_flag;
		
	}

	public static int compare_diff_assertin_insingletest(String assertion1, String assertion2,String assertion3, String assertion4,String assertion5) throws IOException{
		HashMap<String, String> cmp1 = get_assert_apart_intestmethod(assertion1);
		HashMap<String, String> cmp2 = get_assert_apart_intestmethod(assertion2);
		HashMap<String, String> cmp3 = get_assert_apart_intestmethod(assertion3);
		HashMap<String, String> cmp4 = get_assert_apart_intestmethod(assertion4);
		HashMap<String, String> cmp5 = get_assert_apart_intestmethod(assertion5);


		int tmp_kill = 0;
		
		wholeprocess.change_sum = 0;
		
		wholeprocess.fault_sum = 0;		
		
		Iterator iter = cmp1.entrySet().iterator();
		while (iter.hasNext()) {
			HashMap.Entry entry = (HashMap.Entry) iter.next();
			String tmp_method = (String) entry.getKey();
			if(compare_unit(cmp1, cmp2, tmp_method)){ // x1 == y1 go on
				continue;
			}
			if(!compare_unit(cmp3, cmp4, tmp_method)){ // x2 != y2
				continue;
			}
			if(compare_unit(cmp4, cmp5, tmp_method)){
				tmp_kill = 2;
				wholeprocess.fault_sum++;
			}
			else
				wholeprocess.change_sum++;
			
		}
		return tmp_kill;
		
/*
		
		int tmp_kill = 0;
		
		int tmp_change = 0;
		int tmp_fault = 0;
		
		
		Iterator iter = cmp1.entrySet().iterator();
		while (iter.hasNext()) {
			HashMap.Entry entry = (HashMap.Entry) iter.next();
			String tmp_method = (String) entry.getKey();
			if(compare_unit(cmp1, cmp2, tmp_method)){ // x1 == y1 go on
				continue;
			}
			if(!compare_unit(cmp3, cmp4, tmp_method)){ // x2 != y2
				continue;
			}
			if(compare_unit(cmp4, cmp5, tmp_method)){
				tmp_kill = 2;
				break;
			}
			else
				tmp_kill = 3;
			
		}
		return tmp_kill;*/
	}
	
	public static boolean compare_unit(HashMap<String, String> cmp1, HashMap<String, String> cmp2, String testname){
		
		boolean diff_flag = false;
		if(!cmp1.containsKey(testname) && !cmp2.containsKey(testname))
			diff_flag = false;
		else if((!cmp1.containsKey(testname) && cmp2.containsKey(testname)) || (cmp1.containsKey(testname) && !cmp2.containsKey(testname)))
			diff_flag = true;
		else if(cmp1.containsKey(testname) && cmp2.containsKey(testname)){
			if(cmp1.get(testname).equals(cmp2.get(testname)))
				diff_flag = false;
			else
				diff_flag = true;
		}
		return diff_flag;
		
	}
}
