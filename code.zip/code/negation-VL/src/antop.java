import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.DefaultLogger;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.ProjectHelper;
import org.omg.PortableServer.ServantActivator;

public class antop {

	public static void ant_command_collect_load_branch_assert(String buildxml){
		
		
		Project p = new Project();
	//	System.out.println("using fault-strace");

	/*	DefaultLogger consoleLogger1 = new DefaultLogger();
		consoleLogger1.setErrorPrintStream(System.err);
		consoleLogger1.setOutputPrintStream(System.out);
		consoleLogger1.setMessageOutputLevel(Project.MSG_INFO);
		p.addBuildListener(consoleLogger1);*/
		File buildFile1 = new File(buildxml);
		try {
			p.fireBuildStarted();
			p.init();
			ProjectHelper.configureProject(p, buildFile1);
			p.executeTarget("collectBranchCoverage");
			p.executeTarget("loadBranchCoverage");
			p.fireBuildFinished(null);

		} catch (BuildException be) {
			p.fireBuildFinished(be);
		}

		System.out.println("fault- trace is finished");
		return;
	}
	
	public static void load_branch_assertoutput(boolean negate_flag, String buildxml, String faultfilepath) throws IOException{ // load branch assert in negate or not
		File faultfile = new File(faultfilepath);
		if(faultfile.exists())
			FileUtils.cleanDirectory(faultfile);
		
		smallopAPI.set_xml_to_true_false(negate_flag, buildxml);
		ant_command_collect_load_branch_assert(buildxml);
	}
	
	
	
}
