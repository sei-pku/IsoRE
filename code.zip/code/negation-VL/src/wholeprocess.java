import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Queue;

import org.apache.maven.shared.invoker.MavenInvocationException;

public class wholeprocess {

static int mutant_sum = 200;
	
	static String project1_name = "jopt-simple-01";
	static String project2_name = "jopt-simple-02";
	
	static String v1_home = "F:\\work\\FSE\\negationBranch\\experiment\\projects\\jopt-simple1\\v1";
	static String v2_home = "F:\\work\\FSE\\negationBranch\\experiment\\projects\\jopt-simple1\\v2";
	static String original_project2_home = "F:\\work\\FSE\\negationBranch\\experiment\\projects\\jopt-simple1\\originalv2\\jopt-simple-02";

	
	
	static String result_path = "F:\\work\\FSE\\negationBranch\\experiment\\projects\\jopt-simple1\\result";
	
	static String mutants_dir_path = "F:\\work\\FSE\\negationBranch\\experiment\\projects\\jopt-simple1\\mutants";
	static String src_prefic = "joptsimple";     
	static String project_prefix = "joptsimple";
	
	
	static String src_dir_prefix = "\\src\\main\\java";
	static String testsrc_dir_prefix = "\\src\\test\\java";
	static String testbinary_dir_prefix = "\\target\\test-classes";
	
	
	static String exclu_class = "";
	static String add_path1 ="C:\\Users\\user\\.m2\\repository\\junit\\junit\\4.8.2\\junit-4.8.2.jar;";
	static String add_path2 = "C:\\Users\\user\\.m2\\repository\\junit\\junit\\4.8.2\\junit-4.8.2.jar;";
	
	
	
	
	static String rt_path = "F:\\work\\FSE\\negationBranch\\experiment\\lib\\rt.jar";
	static String jsse_path = "F:\\work\\FSE\\negationBranch\\experiment\\lib\\jsse.jar";
	static String jce_path = "F:\\work\\FSE\\negationBranch\\experiment\\lib\\jce.jar";
	static String disk_path = "F:";	
	static int depth = 1;								
	static int negation_branch_limitation = 10000;			
	static int strategy = 0;
	




	
	
	

	

	
	
	
	//**********************************path invariable*************************//
	static String project1_home = v1_home + "\\" + project1_name;
	static String project2_home = v2_home + "\\" + project2_name;
	
	static String src_dir_path = project2_home + src_dir_prefix;
	
	static String faltfilesdir1 = project1_home + "\\faulttracer-files";
	static String faltfilesdir2 = project2_home + "\\faulttracer-files";
	static String faltfilesdiro2 = original_project2_home + "\\faulttracer-files";
	
	
	static String assertoutput1 = project1_home+ "\\faulttracer-files\\assertion-output";	// assertion-output of v1
	static String assertoutput2 = project2_home + "\\faulttracer-files\\assertion-output";	// assertion-output of v2
	static String assertoutputo2 = original_project2_home + "\\faulttracer-files\\assertion-output"; // assertion-output of original v2
	
	static String assertlogpath = result_path + "\\assertlog"; // assert value of original v2 after negation
	
	static String buildxmlfile1 = project1_home + "\\build.xml";	            //build.xml path of v1
	static String buildxmlfile2 = project2_home + "\\build.xml";	            // build.xml path of v2
	static String buildxmlfileo2 = original_project2_home + "\\build.xml"; // build.xml path of original v2
	static String pomxmlfile1 = project1_home + "\\pom.xml";	            //build.xml path of v1
	static String pomxmlfile2 = project2_home + "\\pom.xml";	            // build.xml path of v2
	static String pomxmlfileo2 = original_project2_home + "\\pom.xml"; // build.xml path of original v2
	
	static String binpath_firstv = project1_home + "\\target\\classes";	    // class path of v1
	static String binpath_sencondv = project2_home + "\\target\\classes";	// class path of v2
	
	static String one_line_branch_log = result_path +  "\\0\\branches_on_the_sameline.txt";
	static String all_branch_log =  result_path +  "\\0\\branches_intotal.txt";

	
	static String negate_list1 = project1_home + "\\branches2negate.dat";	// branch2negate.dat path of v1
	static String negate_list2 = project2_home + "\\branches2negate.dat";	// branch2negate.dat path of v2
	static String negate_listo2 = original_project2_home + "\\branches2negate.dat"; // branch2negate.dat path of original v2
	
	static String cove_data = project2_home + "\\faulttracer-files\\branch-coverage.dat";	// branchcoverage.dat path of v2
	
	static String skip1 = project1_home + "\\skipped-tests.dat";
	static String skip2 = project2_home + "\\skipped-tests.dat";
	static String skipo2 = original_project2_home + "\\skipped-tests.dat";
	
	
	static String exclude_data1 = project1_home + "\\excluded-classes.dat";
	static String exclude_data2 = project2_home + "\\excluded-classes.dat";
	static String exclude_datao2 = original_project2_home + "\\excluded-classes.dat";
	
	//************************************************************************************************************//
	
	
	//***************************path variable*************************//
	static String logpath = "";	
	static String assertx1path = ""; // assertvalue of v1 before ng
	static String assertx2path = ""; // assertvalue of v1 after ng
	static String asserty1path = ""; // assertvalue of v2 before ng
	static String asserty2path = ""; // assertvalue of v2 after ng
	static String asserto1path = ""; // assertvalue of original v2 before ng
	static String asserto2path = ""; // assertvalue of original v2 after ng
	

	
	static String killpath = "";
	static int mutant_kill;
	
	static int change_sum;
	static int fault_sum;
	static int count_negate;

	//*****************************************************************//
	
	
	

	// **************************************static variable****************************************//


	
	static HashMap<String, String> totalProjectMap = new HashMap<String, String>();  // the map relation of branch in v2 and branch in v1(v2, v1) 
	static HashSet<String> AllMatchedNodeInV2 = new HashSet<String>(); // in v2, the node has mapped node in v1, include branch node and un-branch node
	static HashMap<String, myunit> map_branch_and_myunit = new HashMap<String, myunit>(); // in v2, the map relation between branch node and its unit 
	static HashSet<mygraph> all_graph = new HashSet<mygraph>(); // keep each mygraph
	
	
	static HashSet<String> branch_cover_beforeNG_total = new HashSet<String>();
	static HashSet<String> branch_cover_AftereNG_total = new HashSet<String>();

//	static HashSet<String> covered_once_branch = new HashSet<String>();
	static HashMap<String, HashSet<String>> originalcove = new HashMap<String, HashSet<String>>();
//	static Queue<List<String>> negate_queue = new ArrayDeque<List<String>>();
	
	
	//*****************************************************************************************************************//
	
	
	
	
	
	

	
	
	public static void main(String[] args) throws IOException, MavenInvocationException {
		
		
		smallopAPI.setup(); // clear , timeout, exclude
		smallopAPI.step1();
		
		List<Integer> random_mutant = new ArrayList<Integer>();
	/*	for(int i = 272; i<= mutant_sum; i++)
			random_mutant.add(i);
		Collections.shuffle(random_mutant);
		FileWriter fw = new FileWriter(new File(result_path + "\\random.txt"));
		BufferedWriter bw = new BufferedWriter(fw);
		for(Integer item: random_mutant){
			bw.write(String.valueOf(item));
			bw.newLine();
		}
		bw.close();
		fw.close();*/
		
	//	smallopAPI.mutantloop(1100);
	//	smallopAPI.write_kill_result();
		
		// point start
		FileReader fr = new FileReader(new File(result_path + "\\random.txt"));
		BufferedReader br = new BufferedReader(fr);
		String tmp;
		random_mutant.clear();
		while((tmp = br.readLine())!= null){
			int tmp_number = Integer.parseInt(tmp);
			random_mutant.add(tmp_number);
		}
		br.close();
		fr.close();
		
		
		
		
		for(int i = 0; i < random_mutant.size(); i++){
		//	if(i == 13) is for joptsimple
		//		continue;
			
			System.out.println("mutantloop");
			smallopAPI.mutantloop(random_mutant.get(i));
			smallopAPI.write_kill_result();
		}
		
		
		// TODO Auto-generated method stub
	//	for(int i = 1; i <= 249; i++){
		//	if(i == 13) is for joptsimple
		//		continue;
			
	//		System.out.println("mutantloop");
	//		smallopAPI.mutantloop(i);
	//		smallopAPI.write_kill_result();
	//	}
		
	}

}
