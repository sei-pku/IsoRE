import java.util.List;
import soot.SootMethod;
import soot.Unit;

public class myunit {

	public String myname; // the conteng of the unit
	public String mytag; // the classname+linenumber
	public List<myunit> myson;
	
}

