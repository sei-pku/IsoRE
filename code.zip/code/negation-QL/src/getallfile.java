
import java.io.IOException;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
public class getallfile {
	static List<File> cFile= new ArrayList<File>();

	public static void readAllFile(String filePath) throws IOException {
		File f = null;
		f = new File(filePath);
		File[] files = f.listFiles(); 

		for (File file : files) {
			if(file.isDirectory()) {
				readAllFile(file.getAbsolutePath());
			} else {
				cFile.add(file);
			}
		}
	}
}
