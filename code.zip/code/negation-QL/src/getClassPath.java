

import java.io.IOException;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.io.IOException;
public class getClassPath {
	static List<File> cFile= new ArrayList<File>();
	public static void setcFile(List<File> cFile) {
		getClassPath.cFile = cFile;
	}
	//static String path = "C:\\Users\\Marina\\Documents\\aaaCoverageImprovement\\faulttracer-negator\\examples\\bank-account1.0\\bin";
	public static List<File> readAllFile(String filePath) throws IOException {
		File f = null;
		f = new File(filePath);
		File[] files = f.listFiles(); 
		List<File> list = new ArrayList<File>();

		for (File file : files) {
			if(file.isDirectory()) {
				readAllFile(file.getAbsolutePath());
			} else {
				list.add(file);
			}
		}
		for(File file : files) {
		cFile.add(file);
	}
		return cFile;
	}
}


