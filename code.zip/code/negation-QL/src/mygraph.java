import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.channels.WritableByteChannel;
import java.util.ArrayList;
import soot.Unit;
import soot.toolkits.graph.UnitGraph;

public class mygraph {
	public myunit myhead;
	public String methodname;
	public String classname;
	public mygraph(String sootclassname, String sootmethodname){
		methodname = sootmethodname;
		classname = sootclassname;
		myhead = new myunit(); 
	}
	public void store_the_graph(myunit mypre,  Unit sootpre, UnitGraph sootg) throws IOException{
		MAPtotal.map_in_store.put(sootpre, mypre);
		MAPtotal.visited_in_store.add(sootpre);
		
		mypre.myname = sootpre.toString();
		mypre.mytag =  classname + ":" + sootpre.getTags().toString().substring(sootpre.getTags().toString().indexOf("[") + 1,sootpre.getTags().toString().indexOf("]"));
	//	if(!MAPtotal.mutibranch.containsKey(mypre.mytag))
	//		MAPtotal.mutibranch.put(mypre.mytag, 0);
		
	//	int current_count = MAPtotal.mutibranch.get(mypre.mytag);
	//	current_count++;
		
		
		
	/*	File f = new File("D:\\lly\\negation-experiment\\projects\\commons-digester\\result\\test.txt");
		FileWriter fw = new FileWriter(f,true);
		BufferedWriter bw = new BufferedWriter(fw);
		bw.write(mypre.mytag);
		bw.write("!!!!!");
		bw.write(String.valueOf(current_count));
		bw.newLine();
		bw.close();
		fw.close();*/
		
		
		
		
		//MAPtotal.mutibranch.put(mypre.mytag,current_count);
		//mypre.mytag += ":" + String.valueOf(current_count);
		

		
		
		
		mypre.myson = new ArrayList<myunit>();
		if(sootg.getSuccsOf(sootpre).size() == 0){
		}
		else if(sootg.getSuccsOf(sootpre).size() == 1){
			if(MAPtotal.visited_in_store.contains(sootg.getSuccsOf(sootpre).get(0)))
				mypre.myson.add(MAPtotal.map_in_store.get(sootg.getSuccsOf(sootpre).get(0)));
			else{
				myunit createone = new myunit();
				mypre.myson.add(createone);
				store_the_graph(createone, sootg.getSuccsOf(sootpre).get(0), sootg);
			}
		}
		else if(sootg.getSuccsOf(sootpre).size() == 2){
			if(MAPtotal.visited_in_store.contains(sootg.getSuccsOf(sootpre).get(0)))
				mypre.myson.add(MAPtotal.map_in_store.get(sootg.getSuccsOf(sootpre).get(0)));
			else{
				myunit createone = new myunit();
				mypre.myson.add(createone);
				store_the_graph(createone, sootg.getSuccsOf(sootpre).get(0), sootg);
			}
			if(MAPtotal.visited_in_store.contains(sootg.getSuccsOf(sootpre).get(1)))
				mypre.myson.add(MAPtotal.map_in_store.get(sootg.getSuccsOf(sootpre).get(1)));
			else{
				myunit createone = new myunit();
				mypre.myson.add(createone);
				store_the_graph(createone, sootg.getSuccsOf(sootpre).get(1), sootg);
			}
		}
	}
}
