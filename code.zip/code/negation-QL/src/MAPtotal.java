
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import org.apache.tools.ant.taskdefs.optional.clearcase.ClearCase;

import com.sun.xml.internal.bind.v2.model.core.ID;

import soot.Scene;
import soot.SootClass;
import soot.SootMethod;
import soot.Unit;
import soot.options.Options;
import soot.toolkits.graph.BriefUnitGraph;
import soot.toolkits.graph.UnitGraph;

public class MAPtotal {
	
	
	static HashMap<Unit, myunit> map_in_store = new HashMap<Unit, myunit>();
	static HashSet<Unit> visited_in_store = new HashSet<Unit>();
	static HashSet<SootClass> soot_class_list = new HashSet<SootClass>();

	
	// get the graphs
	public static HashMap<String, mygraph> getUnitGraphs(String path, boolean flag) {
		HashMap<String, mygraph> hashMap = new HashMap<String, mygraph>();
		soot_class_list.clear();
		try {
			Options.v().setPhaseOption("jb", "use-original-names:true");
			Options.v().set_keep_line_number(true);
			getClassPath.readAllFile(path).clear();
			List<File> files_s = getClassPath.readAllFile(path);
			
			for (File file_s : files_s) {
				String path_s = file_s.getAbsolutePath();
				if(flag == false)
					Scene.v().setSootClassPath(path + ";" + wholeprocess.rt_path + ";" + wholeprocess.jsse_path + ";" + wholeprocess.add_path1);
				else
					Scene.v().setSootClassPath(path + ";" + wholeprocess.rt_path + ";"+ wholeprocess.jsse_path + ";"  + wholeprocess.add_path2);
				
				if (path_s.endsWith(".class") && (!(path_s.toString().contains("test")))&& (!(path_s.toString().contains("Test")))) {
					// load class
					String pathToWrite = null;
					if(path_s.toString().contains("bin")){
						pathToWrite = path_s.substring(path_s.indexOf("bin") + 4, path_s.indexOf(".class"));
					}
					if(path_s.toString().contains("build")){
						pathToWrite = path_s.substring(path_s.indexOf("build") + 6, path_s.indexOf(".class"));
					}
					if(path_s.toString().contains("target")){
						pathToWrite = path_s.substring(path_s.indexOf("classes") + 8, path_s.indexOf(".class"));
					}
					String className = pathToWrite.replaceAll("\\\\", ".");
					System.out.println(className);
					if(!className.equals(wholeprocess.exclu_class) && className.contains(wholeprocess.project_prefix))
						soot_class_list.add(Scene.v().loadClassAndSupport(className));
				}
			}
			
			
			for(SootClass sootclass_s: soot_class_list){
				// get method and store the method
				for (int i = 0; i < sootclass_s.getMethodCount(); i++) {
					SootMethod sootmethod_d = sootclass_s.getMethods().get(i);
					String key_sootmethodname = sootmethod_d.toString();
					if(!sootmethod_d.isConcrete())
						hashMap.put(key_sootmethodname, null);
					else{
						Scene.v().loadNecessaryClasses();
						soot.Body sootbody_y = sootmethod_d.retrieveActiveBody();
						UnitGraph sootgraph_h = new BriefUnitGraph(sootbody_y);
						mygraph graph_to_store = new mygraph(sootmethod_d.getDeclaringClass().toString(), sootmethod_d.getName());
						visited_in_store.clear();
						map_in_store.clear();
						graph_to_store.store_the_graph(graph_to_store.myhead, sootgraph_h.getHeads().get(0), sootgraph_h);
						
						hashMap.put(key_sootmethodname, graph_to_store);
					}
				}
			}				
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return hashMap;
	}

	// If map the CFG bewteen 1v and 2v, save the node in totalprojectmap<b1', b1>,
	public static void methodMap(boolean flag) throws IOException {
		
		wholeprocess.totalProjectMap.clear();       // the map relation of branch in v2 and branch in v1(v2, v1) 
		wholeprocess.AllMatchedNodeInV2.clear();    // in v2, the node has mapped node in v1, include branch node and un-branch node
		wholeprocess.map_branch_and_myunit.clear(); // in v2, the map relation between branch node and its unit 
		wholeprocess.all_graph.clear();             // keep each mygraph
		
		
		
		
		
		HashMap<String, mygraph> h_firstv = new HashMap<String, mygraph>();
		HashMap<String, mygraph> h_secondv = new HashMap<String, mygraph>();
		soot.G.reset();
		h_firstv = getUnitGraphs(wholeprocess.binpath_firstv,false);
		soot.G.reset();
		h_secondv = getUnitGraphs(wholeprocess.binpath_sencondv,true);

		
		
		
		Iterator<String> iterator_secondv = h_secondv.keySet().iterator();
		while (iterator_secondv.hasNext()) {
			Object key0 = iterator_secondv.next();
			wholeprocess.totalProjectMap.putAll(mapnode.newmatch(h_secondv.get(key0),h_firstv.get(key0),flag));
		}
		return;
		
	}

}
