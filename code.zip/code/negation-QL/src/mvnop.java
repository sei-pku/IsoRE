import java.io.File;
import java.util.Arrays;

import org.apache.maven.shared.invoker.DefaultInvocationRequest;
import org.apache.maven.shared.invoker.DefaultInvoker;
import org.apache.maven.shared.invoker.InvocationRequest;
import org.apache.maven.shared.invoker.Invoker;
import org.apache.maven.shared.invoker.MavenInvocationException;

public class mvnop {

	public static void mvn_command(String opera, String pomxml) throws MavenInvocationException{
		
		
		
		InvocationRequest request = new DefaultInvocationRequest();
        request.setPomFile(new File(pomxml));
        request.setGoals(Arrays.asList(opera));

        Invoker invoker = (Invoker) new DefaultInvoker();
        invoker.execute(request);


	}
	
	
}
