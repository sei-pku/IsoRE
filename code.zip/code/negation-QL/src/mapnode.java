

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Stack;

import javax.swing.text.html.HTML.Tag;

import soot.Scene;
import soot.SootMethod;
import soot.Unit;
import soot.toolkits.graph.BriefUnitGraph;
import soot.toolkits.graph.UnitGraph;
import sun.nio.cs.UTF_32;
import sun.swing.UIAction;

public class mapnode {

	static HashMap<myunit, HashSet<myunit>> visited = new HashMap<myunit, HashSet<myunit>>(); // for node match
	static HashSet<myunit> weak_visited = new HashSet<myunit>(); //for to search all the v2 to find out the total number of branches
	static HashSet<String> branch_set = new HashSet<String>();
	static HashMap<String, Integer> mutibranch=new HashMap<String, Integer>();
	
	public static HashMap<String, String> newmatch(mygraph g1, mygraph g2, boolean need_write) throws IOException{
		HashMap<String,String >mappedUnits= new HashMap<String, String>();
		mappedUnits.clear();
		visited.clear();
		weak_visited.clear();
		branch_set.clear();
		mutibranch.clear();
		
		if(g1 != null){
			wholeprocess.all_graph.add(g1);
			find_total_branches(g1.myhead,need_write);
		}
		
		visited.clear();
		weak_visited.clear();
		branch_set.clear();
		mutibranch.clear();
		
		if(g2 != null)
			find_total_branches(g2.myhead, false);
			
		
		if(g1 == null || g2 == null)
			return mappedUnits;

		 
		
		
		// the link node head
		myunit pre1 = g1.myhead;
		myunit pre2 = g2.myhead;
		comparenode(pre1, pre2, mappedUnits);			
		return mappedUnits;
	}

	
	public static void comparenode(myunit u1, myunit u2, HashMap<String, String> result){
		if(visited.containsKey(u1) == false){  // if u1 doesn't exist, then add
			HashSet<myunit> createone = new HashSet<myunit>();
			visited.put(u1, createone);
		}
		
		if(visited.get(u1).contains(u2)) // if u1 is visited by u2, return
			return;
	
		visited.get(u1).add(u2);   // else mark u1 is visited by u2
		
		
		// judge whether  u1 == u2 
		
		if(u1.myname.equals(u2.myname)){ // if u1 == u2	
			wholeprocess.AllMatchedNodeInV2.add(u1.mytag);
			
			if (u1.myson.size() == 2 && u2.myson.size() == 2) { // if u1 and u2 both contain conditions
				wholeprocess.map_branch_and_myunit.put(u1.mytag, u1);
				result.put(u1.mytag, u2.mytag);					//store the matched nodes
			//	System.out.println("matched:" + u1.mytag + " and "+ u2.mytag);
			}
			
			myunit son1, son2;
			if(u1.myson.size() >= 1 && u2.myson.size() >= 1){ // both have more than one son
				son1 = u1.myson.get(0);
				son2 = u2.myson.get(0);
				comparenode(son1, son2, result);
			}
			
			if(u1.myson.size() >= 2 && u2.myson.size() >= 2){ // both have two sons
				son1 = u1.myson.get(1);
				son2 = u2.myson.get(1);
				comparenode(son1, son2, result);
			}
		}
	}
	
	
	public static void find_total_branches(myunit u1,boolean need_write) throws IOException{
		if(weak_visited.contains(u1)){
			return;
		}
		else
			weak_visited.add(u1);
	
		if(u1.myson.size() == 2){
			
			
			if(!mutibranch.containsKey(u1.mytag))
				mutibranch.put(u1.mytag, 0);
				
			int current_count = mutibranch.get(u1.mytag);
			current_count++;
			mutibranch.put(u1.mytag,current_count);
			u1.mytag += ":" + String.valueOf(current_count);
				
			
			
			if(need_write){
				FileWriter fw1 = new FileWriter(new File(wholeprocess.all_branch_log), true);
				BufferedWriter bw1 = new BufferedWriter(fw1);
				bw1.write(u1.mytag);
				bw1.newLine();
				bw1.close();
				fw1.close();
			}
			if(branch_set.contains(u1.mytag)){
				if(need_write){
				FileWriter fw1 = new FileWriter(new File(wholeprocess.one_line_branch_log), true);
				BufferedWriter bw1 = new BufferedWriter(fw1);
				bw1.write(u1.mytag);
				bw1.newLine();
				bw1.close();
				fw1.close();
				}
			}
			branch_set.add(u1.mytag);
			find_total_branches(u1.myson.get(0),need_write);
			find_total_branches(u1.myson.get(1),need_write);
		}
		else if(u1.myson.size() == 1){
			find_total_branches(u1.myson.get(0),need_write);
		}					
	}
}
