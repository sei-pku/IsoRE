import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Queue;
import java.util.Stack;

import soot.dava.toolkits.base.AST.analysis.Analysis;

public class approach {
	static HashSet<myunit> visited = new HashSet<myunit>();
	
	static void get_increase_branch() throws IOException{ // get the increase coverage
	
		int average_branch_increase = 0;
		MAPtotal.methodMap(true); 
		wholeprocess.branch_cover_beforeNG_single.clear();
		wholeprocess.branch_cover_AftereNG_single.clear();
		
		HashMap<String, HashSet<String>> cove_once = analysis_coverage_inall(true, true);
		

		for(String testname: wholeprocess.test_list) {
			HashSet<String> cove_once_inonetest = cove_once.get(testname);
			Queue<List<String>> negate_queue= initial_queue(cove_once_inonetest);
			negate(wholeprocess.strategy, negate_queue, true, false, testname);



			// record the result 
			File frb = new File(wholeprocess.logpath + "\\branch-before-negation" + testname + ".txt");
			FileWriter fwb = new FileWriter(frb);
			BufferedWriter bwb = new BufferedWriter(fwb);
			bwb.write(String.valueOf(wholeprocess.branch_cover_beforeNG_single.get(testname).size()));
			bwb.newLine();
			for(String item: wholeprocess.branch_cover_beforeNG_single.get(testname)){
				bwb.write(item);
				bwb.newLine();
			}
			bwb.close();
			fwb.close();
			
			
			frb = new File(wholeprocess.logpath  + "\\branch-after-negation" + testname + ".txt");
			fwb = new FileWriter(frb);
			bwb = new BufferedWriter(fwb);
			bwb.write(String.valueOf(wholeprocess.branch_cover_AftereNG_single.get(testname).size()));
			bwb.newLine();
			for(String item: wholeprocess.branch_cover_AftereNG_single.get(testname)){
				bwb.write(item);
				bwb.newLine();
			}
			bwb.close();
			fwb.close();
			
			frb = new File(wholeprocess.logpath  + "\\branch_increase" + testname + ".txt");
			fwb = new FileWriter(frb);
			bwb = new BufferedWriter(fwb);
			for(String item: wholeprocess.branch_cover_AftereNG_single.get(testname)){
				if(wholeprocess.branch_cover_beforeNG_single.get(testname).contains(item))
					continue;
				bwb.write(item);
				bwb.newLine();
				average_branch_increase++;
			}
			bwb.close();
			fwb.close();		
		}
		
		File fav = new File(wholeprocess.logpath + "\\average_branch_increase.txt");
		FileWriter fwav = new FileWriter(fav);
		BufferedWriter bwb = new BufferedWriter(fwav);
		bwb.write(String.valueOf(average_branch_increase));
		bwb.newLine();
		bwb.close();
		fwav.close();
			
	}
		
	
	static HashMap<String, HashSet<String>> analysis_coverage_inall(boolean write_bn, boolean write_an) throws IOException {// analysis the coverage

		wholeprocess.test_list.clear();
		HashMap<String, HashSet<String>> cover_once = new HashMap<String, HashSet<String>>();
		cover_once.clear();
		

		HashSet<String> branch_true = new HashSet<String>();
		HashSet<String> branch_false = new HashSet<String>();

		FileReader fr = new FileReader(new File(wholeprocess.cove_data));
		BufferedReader br = new BufferedReader(fr);
		String tmp_string_for_read;
		String tmp_string_for_branchname;
		String tmp_string_for_testname;
		String tmp_string_list[];
		while ((tmp_string_for_read = br.readLine()) != null) {

			branch_false.clear();
			branch_true.clear();
			tmp_string_list = tmp_string_for_read.trim().split(" ");

			String tt_a[] = tmp_string_list[0].split("-");
			int tt_l = tt_a.length;
			int tt_i = 1;
			tmp_string_for_testname = tt_a[0];
			while (tt_i < tt_l - 1) {
				tmp_string_for_testname += "-" + tt_a[tt_i];
				tt_i++;
			}

			int i = 1;
			while (i < tmp_string_list.length) {

				String t_a[] = tmp_string_list[i].split(":");
				int t_l = t_a.length;
				int t_i = 1;
				tmp_string_for_branchname = t_a[0].trim().split("\\$\\$")[0];
				while (t_i < t_l) {
					tmp_string_for_branchname = tmp_string_for_branchname + ":" + t_a[t_i];
					t_i++;
				}

				if (!tmp_string_for_branchname.contains("test") && !tmp_string_for_branchname.contains("Test")) {
					// System.out.println(tmp_string_for_branchname);
					if (tmp_string_for_branchname.trim().split(":")[3].contains("<true>")) {
						branch_true.add((tmp_string_for_branchname.trim().split(":")[0]) + ":"
								+ tmp_string_for_branchname.trim().split(":")[1] + ":"
								+ tmp_string_for_branchname.trim().split(":")[2]);
					} else if (tmp_string_for_branchname.trim().split(":")[3].contains("<false>")) {
						branch_false.add((tmp_string_for_branchname.trim().split(":")[0]) + ":"
								+ tmp_string_for_branchname.trim().split(":")[1] + ":"
								+ tmp_string_for_branchname.trim().split(":")[2]);
					}
				}
				i++;
			}

			wholeprocess.test_list.add(tmp_string_for_testname);
			HashSet<String> createone = new HashSet<String>();
			HashSet<String> create1 = new HashSet<String>();
			HashSet<String> create2 = new HashSet<String>();

			for (String item : branch_true) {
				if (write_bn)
					create1.add(item + ":true");
				if (write_an)
					create2.add(item + ":true");
				if (!branch_false.contains(item) && wholeprocess.totalProjectMap.containsKey(item)) {
					createone.add(item);
				}
			}
			for (String item : branch_false) {
				if (write_bn)
					create1.add(item + ":false");
				if (write_an)
					create2.add(item + ":false");
				if (!branch_true.contains(item) && wholeprocess.totalProjectMap.containsKey(item)) {
					createone.add(item);
				}
			}
			cover_once.put(tmp_string_for_testname, createone);
			wholeprocess.branch_cover_beforeNG_single.put(tmp_string_for_testname, create1);
			wholeprocess.branch_cover_AftereNG_single.put(tmp_string_for_testname, create2);
		}

		br.close();
		fr.close();

		return cover_once;
	}
	
	static HashSet<String> analysis_coverage_insingle(boolean write_bn, boolean write_an, String testname) throws IOException{
		HashSet<String>cove_once = new HashSet<String>();
		cove_once.clear();
		HashSet<String> branch_true = new HashSet<String>();
		HashSet<String> branch_false = new HashSet<String>();
		
		FileReader fr = new FileReader(new File(wholeprocess.cove_data));
		BufferedReader br = new BufferedReader(fr);
		
		String tmp_string_for_read;
		String tmp_string_for_branchname;
		String tmp_string_list[];
		String tmp_string_for_testname = "";
		
		while((tmp_string_for_read = br.readLine()) != null){
			
			String tt_a[] = (tmp_string_for_read.split(" ")[0]).split("-");
			int tt_l = tt_a.length;
			int tt_i = 1;
			tmp_string_for_testname = tt_a[0];
			while(tt_i < tt_l - 1){
				tmp_string_for_testname += "-" + tt_a[tt_i];
				tt_i++;
			}
			if(tmp_string_for_testname.equals(testname))
				break;
		}
		
		
		if(!tmp_string_for_testname.equals(testname))
			return cove_once;
		
		
		
		tmp_string_list = tmp_string_for_read.split(" ");
		
		int i = 1;
		while (i < tmp_string_list.length) {
			
			String t_a[] = tmp_string_list[i].split(":");
			int t_l = t_a.length;
			int t_i = 1;
			tmp_string_for_branchname = t_a[0].split("\\$\\$")[0];
			while(t_i < t_l){
				tmp_string_for_branchname = tmp_string_for_branchname + ":" + t_a[t_i];
				t_i++;
			}
			
			if (!tmp_string_for_branchname.contains("test") && !tmp_string_for_branchname.contains("Test")) {
				if (tmp_string_for_branchname.trim().split(":")[3].contains("<true>")) {
					branch_true.add((tmp_string_for_branchname.trim().split(":")[0]) + ":"
							+ tmp_string_for_branchname.trim().split(":")[1] + ":" + tmp_string_for_branchname.trim().split(":")[2]);
				} else if (tmp_string_for_branchname.trim().split(":")[3].contains("<false>")) {
					branch_false.add((tmp_string_for_branchname.trim().split(":")[0]) + ":"
							+ tmp_string_for_branchname.trim().split(":")[1] + ":" + tmp_string_for_branchname.trim().split(":")[2]);
				}
			}
			i++;
		}
		
		br.close();
		fr.close();
		
		for (String item : branch_true) {
			if(write_an)
				wholeprocess.branch_cover_AftereNG_single.get(testname).add(item + ":true");
			if (!branch_false.contains(item) && wholeprocess.totalProjectMap.containsKey(item)) {
				cove_once.add(item);
			}
		}
		for (String item : branch_false) {
			if(write_an)
				wholeprocess.branch_cover_AftereNG_single.get(testname).add(item + ":false");
			if (!branch_true.contains(item) && wholeprocess.totalProjectMap.containsKey(item)) {
				cove_once.add(item);
			}
		}
		return cove_once;
		
	}
	
	static Queue<List<String>> initial_queue(HashSet<String> cove_once){
		Queue<List<String>> negate_queue = new ArrayDeque<List<String>>();
		negate_queue.clear();
		
		for(String item: cove_once){
			List<String> createone = new ArrayList<String>();
			createone.add(item);
			negate_queue.add(createone);
		}
		return negate_queue;

	}

	static void negate(int strategyid, Queue<List<String>> negate_queue,boolean calculate_increase_branch, boolean calculate_kill_mutant, String testname ) throws IOException{
		if(strategyid == 0)
			negate_inorder(negate_queue,calculate_increase_branch, calculate_kill_mutant,testname);
	}
	
	static void negate_inorder( Queue<List<String>> negate_queue, boolean calculate_increase_branch, boolean calculate_kill_mutant, String testname) throws IOException {

	//	int i = 1;
		while (true) {


			if (negate_queue.isEmpty())
				break;

			List<String> present_negate_list = negate_queue.poll();

			
			// judge as the exit of the while loop
			if (present_negate_list == null) 
				break;
			if (present_negate_list.size() > wholeprocess.depth)
				break;

			// write the negate list to the file
		/*	FileWriter log = new FileWriter(new File(wholeprocess.logpath + "\\log" + testname + ".txt"), true);
			BufferedWriter blog = new BufferedWriter(log);
			for (String items : present_negate_list) {
				blog.write(items);
				blog.write(",");
			}
			blog.newLine();
			blog.close();
			log.close();*/

		//	System.out.println("begin to write the negate list");
			FileWriter fw1 = new FileWriter(new File(wholeprocess.negate_list1));
			FileWriter fw2 = new FileWriter(new File(wholeprocess.negate_list2));
			FileWriter fwo2 =  new FileWriter(new File(wholeprocess.negate_listo2));
			
			BufferedWriter bw1 = new BufferedWriter(fw1);
			BufferedWriter bw2 = new BufferedWriter(fw2);
			BufferedWriter bwo2 = new BufferedWriter(fwo2);
			for (String item : present_negate_list) {
				bw2.write(item.split(":")[0] + ":" + item.split(":")[1] + "-" + item.split(":")[2]);
				bw2.newLine();
				bwo2.write(item.split(":")[0] + ":" + item.split(":")[1] + "-" + item.split(":")[2]);
				bwo2.newLine();
				item = wholeprocess.totalProjectMap.get(item);
				bw1.write(item.split(":")[0] + ":" + item.split(":")[1] + "-" + item.split(":")[2]);
				bw1.newLine();
			}
			bw1.close();
			bw2.close();
			fw1.close();
			fw2.close();

			
		//	System.out.println("begin to write the skip list");
			File skipfile1 = new File(wholeprocess.skip1);
			File skipfile2 = new File(wholeprocess.skip2);
			File skipfileo2 = new File(wholeprocess.skipo2);

			if (skipfile1.exists())
				skipfile1.delete();

			if (skipfile2.exists())
				skipfile2.delete();

			if (skipfileo2.exists())
				skipfileo2.delete();
			
			
			fw1 = new FileWriter(skipfile1);
			fw2 = new FileWriter(skipfile2);
			fwo2 = new FileWriter(skipfileo2);
			bw1 = new BufferedWriter(fw1);
			bw2 = new BufferedWriter(fw2);
			bwo2 = new BufferedWriter(fwo2);

			for(String tmp_skip_testname: wholeprocess.test_list){
				if(tmp_skip_testname.equals(testname))
					continue;
				bw1.write(tmp_skip_testname);
				bw1.newLine();
				bw2.write(tmp_skip_testname);
				bw2.newLine();
				bwo2.write(tmp_skip_testname);
				bwo2.newLine();
			}
			

			bw1.close();
			bw2.close();
			fw1.close();
			fw2.close();
			bwo2.close();
			fwo2.close();
			
			
			// call the fault_trace to negate........................
			assertionAPI.clear_all_assertoutput();
			antop.load_branch_assertoutput(true, wholeprocess.buildxmlfile1, wholeprocess.faltfilesdir1);
			antop.load_branch_assertoutput(true, wholeprocess.buildxmlfile2,wholeprocess.faltfilesdir2);
			antop.load_branch_assertoutput(true, wholeprocess.buildxmlfileo2,wholeprocess.faltfilesdiro2);
			
			if(calculate_kill_mutant){
				assertionAPI.move_assertion(wholeprocess.assertoutput1, wholeprocess.assertx2path);
				assertionAPI.move_assertion(wholeprocess.assertoutput2, wholeprocess.asserty2path);
				assertionAPI.move_assertion(wholeprocess.assertoutputo2, wholeprocess.asserto2path);
				int tmp_kill = assertionAPI.compare_diff_assertin_insingletest(wholeprocess.assertx1path, wholeprocess.asserty1path, wholeprocess.assertx2path, wholeprocess.asserty2path, wholeprocess.asserto2path, testname);
				if(tmp_kill == 2)
					wholeprocess.mutant_kill = 2;
				FileWriter log = new FileWriter(new File(wholeprocess.logpath + "\\log" + testname + ".txt"), true);
				BufferedWriter blog = new BufferedWriter(log);
				for (String items : present_negate_list) {
					blog.write(items);
					blog.write(",");
				}
				blog.write(" ");
				blog.write(String.valueOf(tmp_kill));
				blog.newLine();
				blog.close();
				log.close();
				

					
			}
			
			HashSet<String> tmp_cove_once_fordepth = analysis_coverage_insingle(false, calculate_increase_branch, testname);


			if (present_negate_list.size() == wholeprocess.depth)
				continue;

			add_next_depth_negate_branch(testname, present_negate_list, tmp_cove_once_fordepth, negate_queue);

		}
	}
	
	static void add_next_depth_negate_branch(String testname, List<String> present_negate_list, HashSet<String> only_cove_once, Queue<List<String>> negate_queue) throws IOException{
		// find the exact line for this test method
		
		String last_node = present_negate_list.get(present_negate_list.size() - 1);
		myunit tmp_unit = wholeprocess.map_branch_and_myunit.get(last_node);

		int left = 0;
		int right = 0;

		FileReader fr = new FileReader(new File(wholeprocess.cove_data));
		BufferedReader br = new BufferedReader(fr);
		String tmp_string_for_read ;
		String tmp_string_for_testname = "";
		while((tmp_string_for_read = br.readLine()) != null){
			
			String tt_a[] = (tmp_string_for_read.split(" ")[0]).split("-");
			int tt_l = tt_a.length;
			int tt_i = 1;
			tmp_string_for_testname = tt_a[0];
			while(tt_i < tt_l - 1){
				tmp_string_for_testname += "-" + tt_a[tt_i];
				tt_i++;
			}
			if(tmp_string_for_testname.equals(testname))
				break;
		}
		
		
		if(!tmp_string_for_testname.equals(testname))
			return;
		
		
		
		
		String tmp2[] = null; // line content split with " ", still need follows
		String tmp6[] = null; // test name split with "-"
		
		
		tmp2 = tmp_string_for_read.trim().split(" ");
		int r_f = 1;
		while (r_f < tmp2.length) {
			
			String t_a[] = tmp2[r_f].split(":");
			int t_l = t_a.length;
			int t_i = 1;
			String eachbranch = t_a[0].split("\\$\\$")[0];
			while(t_i < t_l){
				eachbranch = eachbranch + ":" + t_a[t_i];
				t_i++;
			}
			
			if (eachbranch.contains(last_node)) { // to left
				if (eachbranch.trim().split(":")[3].contains("<true>")) {
				//	System.out.println("go to left");
				//	System.out.println(eachbranch);
					left = 1;
				} else if (eachbranch.trim().split(":")[3].contains("<false>")) { // to right
					//System.out.println("go to right");
					//System.out.println(eachbranch);
					right = 1;
				} else {
				//	System.out.println("it is not a if-else branch, maybe is a switch, error, exit");
				}
			}
			r_f++;
		}
		br.close();
		fr.close();

		// search for successor branch node which are based on this prefix
		myunit next_of_pre = null;
		Stack<myunit> next_to_negate = new Stack<myunit>();

		if (left == 1 && right == 0) { // it go a true branch, left
			visited.clear();
		//	System.out.println("go to left");
			visited.add(tmp_unit);
			next_of_pre = tmp_unit.myson.get(0); // get the left branch
		//	System.out.println("leftson");
		//	System.out.println(next_of_pre.myname);
			get_next_negate(next_of_pre, next_to_negate, only_cove_once);
		} else if (left == 0 && right == 1) { // it goes a false branch, right
			visited.clear();
	//		System.out.println("go to right");
			visited.add(tmp_unit);
			next_of_pre = tmp_unit.myson.get(1); // get the left branch
		//	System.out.println("rightson");
		//	System.out.println(next_of_pre.myname);
			get_next_negate(next_of_pre, next_to_negate, only_cove_once);
		} else if (left == 1 && right == 1) {
			visited.clear();
			visited.add(tmp_unit);
			next_of_pre = tmp_unit.myson.get(0); // get the left branch
		//	System.out.println("leftson");
		//	System.out.println(next_of_pre.myname);
			get_next_negate(next_of_pre, next_to_negate, only_cove_once);
			next_of_pre = tmp_unit.myson.get(1); // get the right branch
		//	System.out.println("rightson");
		//	System.out.println(next_of_pre.myname);
			visited.clear();
			visited.add(tmp_unit);
			get_next_negate(next_of_pre, next_to_negate, only_cove_once);
		} else {
		//	System.out.println("error cant judge which to go");
			return;
		}

	//	System.out.println("successor negation list");
	//	System.out.println(next_to_negate);
		while (!next_to_negate.isEmpty()) {
			myunit tmp3 = next_to_negate.pop();
			List<String> tmp5 = new ArrayList<String>(present_negate_list);
			tmp5.add(tmp3.mytag);
			negate_queue.add(tmp5);
		}
	}

	static void get_next_negate(myunit pre_unit, Stack<myunit> result, HashSet<String> only_cove_once) {

		if (visited.contains(pre_unit))
			return;
		visited.add(pre_unit);

		String pre_unit_name = pre_unit.mytag;
	//	System.out.println("pre_unit_name");
	//	System.out.println(pre_unit_name);

		if (wholeprocess.AllMatchedNodeInV2.contains(pre_unit_name) == false) {
		//	System.out.println("it goes to an not match node , will return ");
			return;
		}

		if (pre_unit.myson.size() == 0) {
	//		System.out.println("it goese to an node have no son");
			return;
		}

		if (pre_unit.myson.size() == 1) {
			get_next_negate(pre_unit.myson.get(0), result, only_cove_once);
		}

		else if (pre_unit.myson.size() == 2) {
			if (only_cove_once.contains(pre_unit_name)) { //
				result.push(pre_unit);
				return;
			} else {
				get_next_negate(pre_unit.myson.get(0), result, only_cove_once);
				get_next_negate(pre_unit.myson.get(1), result, only_cove_once);
			}
		}
		return;
	}
		
}
